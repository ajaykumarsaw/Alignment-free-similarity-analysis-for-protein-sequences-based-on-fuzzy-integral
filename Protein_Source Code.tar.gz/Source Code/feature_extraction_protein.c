#include<stdio.h>
#include<string.h>
#include<math.h>
// we print only those order say 'p' whose rmsd between two consecutive order 'p' and 'p+1' transition probability matrix is zero.


int main(int argc, char *argv[])
{

if (argc==3)
{ //*************************************

int mal_1;  // argument second is the maximum length of  Protein  sequences   ?????????????????????????????????
mal_1=atoi(argv[2]);


int k,e_t;  // ****************************change parameter*****************
 for(k=1;k<2;k++) // *********k-th step ****for loop*******************
{
/*Input of protein of length of nucleotides  in 1 line */
char pro[mal_1];
int r_1=0;
FILE *input;
input= fopen(argv[1],"r");
while(fgets(pro,mal_1,input)!=NULL)
{
r_1++;  //  for reading even line from input file
if((r_1%2)==0)  // *********
{  //*********
/* Count frequency of symbol */
int i,j,l,N[20][20];
float    P[20][20],U[20][20],Q[20][20];


for(i=0;i<20;i++)
for(j=0;j<20;j++)
{
 N[i][j]=0;
 P[i][j]=0;
 U[i][j]=0;
 Q[i][j]=0;
}
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e_t=0;
e_t=strlen(pro);
for(l=0;l<=e_t;l=l+k)   // ****************k is notable**************
{           //%%%%% start  for loop for all 20 amino acid
// NUMBER 1
if (pro[l]=='A')
{
if((l+k)<= e_t)
{
i=0;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}
// number=2
if (pro[l]=='R')
{
if((l+k)<= e_t)
{
i=1;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number=3

if (pro[l]=='N')
{
if((l+k)<= e_t)
{
i=2;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


//number=4

if (pro[l]=='D')
{
if((l+k)<= e_t)
{
i=3;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

//number=5

if (pro[l]=='C')
{
if((l+k)<= e_t)
{
i=4;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

//number=6

if (pro[l]=='Q')
{
if((l+k)<= e_t)
{
i=5;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

//number=7

if (pro[l]=='E')
{
if((l+k)<= e_t)
{
i=6;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


//number=8

if (pro[l]=='G')
{
if((l+k)<= e_t)
{
i=7;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

//number=9

if (pro[l]=='H')
{
if((l+k)<= e_t)
{
i=8;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


// number=10

if (pro[l]=='I')
{
if((l+k)<= e_t)
{
i=9;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


// number=11

if (pro[l]=='L')
{
if((l+k)<= e_t)
{
i=10;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

//number 12

if (pro[l]=='K')
{
if((l+k)<= e_t)
{
i=11;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number 13

if (pro[l]=='M')
{
if((l+k)<= e_t)
{
i=12;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number 14

if (pro[l]=='F')
{
if((l+k)<= e_t)
{
i=13;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number 15

if (pro[l]=='P')
{
if((l+k)<= e_t)
{
i=14;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number 16

if (pro[l]=='S')
{
if((l+k)<= e_t)
{
i=15;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}

// number 17

if (pro[l]=='T')
{
if((l+k)<= e_t)
{
i=16;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


//number 18

if (pro[l]=='W')
{
if((l+k)<= e_t)
{
i=17;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


// number 19

if (pro[l]=='Y')
{
if((l+k)<= e_t)
{
i=18;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}


// number 20

if (pro[l]=='V')
{
if((l+k)<= e_t)
{
i=19;
if (pro[l+k]=='A')
N[i][0]+=1;
else if (pro[l+k]=='R')
N[i][1]+=1;
else if (pro[l+k]=='N')
N[i][2]+=1;
else if (pro[l+k]=='D')
N[i][3]+=1;
else if (pro[l+k]=='C')
N[i][4]+=1;
else if (pro[l+k]=='Q')
N[i][5]+=1;
else if (pro[l+k]=='E')
N[i][6]+=1;
else if (pro[l+k]=='G')
N[i][7]+=1;
else if (pro[l+k]=='H')
N[i][8]+=1;
else if (pro[l+k]=='I')
N[i][9]+=1;
else if (pro[l+k]=='L')
N[i][10]+=1;
else if (pro[l+k]=='K')
N[i][11]+=1;
else if (pro[l+k]=='M')
N[i][12]+=1;
else if (pro[l+k]=='F')
N[i][13]+=1;
else if (pro[l+k]=='P')
N[i][14]+=1;
else if (pro[l+k]=='S')
N[i][15]+=1;
else if (pro[l+k]=='T')
N[i][16]+=1;
else if (pro[l+k]=='W')
N[i][17]+=1;
else if (pro[l+k]=='Y')
N[i][18]+=1;
else if (pro[l+k]=='V')
N[i][19]+=1;
}
}






}   // end for loop for all 20 amino acid
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 /* Output frequency of protein nucleotides */
/*
for(i=0;i<20;i++)
{
for(j=0;j<20;j++)
printf("%d  ",N[i][j]);
printf("\n");
}
printf("\n");
*/
/*output probability of protein sequence */
for(i=0;i<20;i++)
{
// for handling 0/0 situation  %%%%%%%%%%%
int N_1[20];
N_1[i]= (N[i][0]+N[i][1]+N[i][2]+N[i][3]+N[i][4]+N[i][5]+N[i][6]+N[i][7]+N[i][8]+N[i][9]+N[i][10]+N[i][11]+N[i][12]+N[i][13]+N[i][14]+N[i][15]+N[i][16]+N[i][17]+N[i][18]+N[i][19]);
if(N_1[i]==0)
{
N_1[i]=1;
}
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
for(j=0;j<20;j++)
{
U[i][j]=P[i][j]=(float )N[i][j]/(N_1[i]);
// printf("%f  ",P[i][j]);
}
}
// printf("\n");

float sum,rmsd=1;
while(rmsd>=(float)0.0000005)
{
for(i=0;i<20;i++)
for(j=0;j<20;j++)
{
sum=0;
for(l=0;l<20;l++)
{
Q[i][j]=U[i][l]*P[l][j];
sum=sum+Q[i][j];
}
Q[i][j]=sum;
// printf("%f  ",Q[i][j]);

}
sum=0;
for(i=0;i<20;i++)
for(j=0;j<20;j++)
{
sum=sum+(Q[i][j]-U[i][j])*(Q[i][j]-U[i][j]);
}
sum=sum/400;
sum=sqrt(sum);

for(i=0;i<20;i++)
for(j=0;j<20;j++)
U[i][j]=Q[i][j];

rmsd=sum;
// printf("\n");
}

for(i=0;i<20;i++)
for(j=0;j<20;j++)
printf("%f  ",U[i][j]);

printf("\n");


} // ***************** end if loop(help to directly read from fasta file)
} //end while loop
fclose(input);

}  // **********************finish for loop**********************


}  // ************************* for command linr argument***************



else if (argc < 3 ||argc > 3)
{
printf("Enter Two arguments. 1_path_of_input_file  2_maximum_length_of_Protein_sequences");
printf("\n");
}


return(0);


}

