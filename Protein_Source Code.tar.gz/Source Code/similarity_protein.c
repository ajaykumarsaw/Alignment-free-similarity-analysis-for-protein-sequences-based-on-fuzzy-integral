#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<inttypes.h>
#include<stdint.h>
// #define v 8   //*********** no of rows in input file.
// #define p_1 8   // **** no of species***********************
#define p_2 20  // we took only 1 class among the 20 classes in multiinput matrix.As we increasing the order, we found all different classes, which contains 20 value has  approximately  same value.
// #define NT 2 // NUMBER OF THREAD ASSIGN

int main(int argc, char *argv[])
{


if (argc==4)
{ //*************************************

int v, p_1, NT;
v=p_1=atoi(argv[2]);
NT= atoi(argv[3]); 
int q;
for(q=0;q<v;q=q+p_1)
{
/*printf("FuzzY IntegraL SimilaritY");
printf("\n");
printf("\n");*/
int x,i,j,k,p,t,m=p_1,n=p_2;
float temp=0,temp1=0;
t= (m*(m-1))/2;
float a[v][400];
 float (*c)[p_2],(*b)[p_2],(*d)[p_2],(*e)[p_2];
 c=(float(*)[])malloc(t*p_2*sizeof(float));
 b=(float(*)[])malloc(t*p_2*sizeof(float));
 d=(float(*)[])malloc(t*p_2*sizeof(float));
 e=(float(*)[])malloc(t*p_2*sizeof(float));


for(i=0;i<v;i++)
for(j=0;j<400;j++)
 a[i][j]=0;

for(p=0;p<t;p++)
for(j=0;j<n;j++)
 {
d[p][j]=0;
c[p][j]=0;
b[p][j]=0;
e[p][j]=0;
}

FILE *input;
input= fopen(argv[1],"r");  // keep in mind ***********************************
for(i=0;i<v;i++)
for(j=0;j<400;j++) //  we have to read all files
fscanf(input,"%f",&a[i][j]);



/*
 printf("calculation for mu slot"); 
 printf("\n");
// -----------------------------------------------
printf("*****************-------------------------------");
printf("\n");

*/
p=-1;
for(i=0;i<m-1;i++)
for(k=i+1;k<m;k++)
{
p++;
for(j=0;j<n;j++)
{
if(a[i+q][j]>a[k+q][j])
{
b[p][j]=a[i+q][j];
// printf("%f  ",b[p][j]);
}
else
{
b[p][j]=a[k+q][j];
// printf("%f  ",b[p][j]);
}
}
// printf("\n");
}

/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ",b[i][j]);
 printf("\n");
} 
 



// ---------------------------------------modify upto here %%%%%%%%%%%%%%%%%%%%%%----
printf("\n");
printf("\n");

 printf(" CALCULATION for lambda value using  NEWTON RAPSON METHOD");
//--------------------------------

printf("\n ----------------------------------------------------");
printf("CALCULATE COEFFICIENT -------------------");
printf("\n");
printf("\n");

*/
// START PARALLEL COMPUTATION  *************************************
//*****************************************************************
//******************************************************************

omp_set_dynamic(0);
omp_set_num_threads(NT);
#pragma omp parallel default(none), private(i,j) shared(t,n,b,d)
{
#pragma omp for
for(i=0;i<t;i++)
for(j=0;j<n;j=j+20)
{
// set intput for 20 parameter  **********
int i_1,i_2,i_3,i_4,i_5,i_6,i_7,i_8,i_9,i_10,i_11,i_12,i_13,i_14,i_15,i_16,i_17,i_18,i_19,i_20;
float s_1=-1; // in newton ropson method, (sum of all coefficient taken i at a time)-1
float s_2=0,s_3=0,s_4=0,s_5=0,s_6=0,s_7=0,s_8=0,s_9=0,s_10=0,s_11=0,s_12=0,s_13=0,s_14=0,s_15=0,s_16=0,s_17=0,s_18=0,s_19=0,s_20=0;
 
// ********************************************
//***************************************************
for(i_1=0;i_1<20;i_1++)
{ //1
d[i][j+19]=b[i][j+i_1]+s_1;
s_1=d[i][j+19];
for(i_2=i_1+1;i_2<20;i_2++)
{ //2
d[i][j+18]=(b[i][j+i_1]*b[i][j+i_2])+s_2;
s_2=d[i][j+18];
for(i_3=i_2+1;i_3<20;i_3++)
{ // 3
d[i][j+17]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3])+s_3;
s_3=d[i][j+17];
for(i_4=i_3+1;i_4<20;i_4++)
{ // 4
d[i][j+16]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4])+s_4;
s_4=d[i][j+16];
for(i_5=i_4+1;i_5<20;i_5++)
{ // 5
d[i][j+15]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5])+s_5;
s_5=d[i][j+15];
for(i_6=i_5+1;i_6<20;i_6++)
{ // 6
d[i][j+14]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6])+s_6;
s_6=d[i][j+14];
for(i_7=i_6+1;i_7<20;i_7++)
{ // 7
d[i][j+13]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7])+s_7;
s_7=d[i][j+13];
for(i_8=i_7+1;i_8<20;i_8++)
{ // 8
d[i][j+12]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8])+s_8;
s_8=d[i][j+12];
for(i_9=i_8+1;i_9<20;i_9++)
{ // 9
d[i][j+11]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9])+s_9;
s_9=d[i][j+11];
for(i_10=i_9+1;i_10<20;i_10++)
{ // 10
d[i][j+10]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10])+s_10;
s_10=d[i][j+10];

for(i_11=i_10+1;i_11<20;i_11++)
{ // 11
d[i][j+9]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11])+s_11;
s_11=d[i][j+9];

for(i_12=i_11+1;i_12<20;i_12++)
{ // 12
d[i][j+8]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12])+s_12;
s_12=d[i][j+8];

for(i_13=i_12+1;i_13<20;i_13++)
{ // 13
d[i][j+7]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13])+s_13;
s_13=d[i][j+7];

for(i_14=i_13+1;i_14<20;i_14++)
{ // 14
d[i][j+6]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14])+s_14;
s_14=d[i][j+6];

for(i_15=i_14+1;i_15<20;i_15++)
{ // 15
d[i][j+5]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15])+s_15;
s_15=d[i][j+5];

for(i_16=i_15+1;i_16<20;i_16++)
{ // 16
d[i][j+4]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15]*b[i][j+i_16])+s_16;
s_16=d[i][j+4];

for(i_17=i_16+1;i_17<20;i_17++)
{ // 17
d[i][j+3]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15]*b[i][j+i_16]*b[i][j+i_17])+s_17;
s_17=d[i][j+3];

for(i_18=i_17+1;i_18<20;i_18++)
{ // 18
d[i][j+2]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15]*b[i][j+i_16]*b[i][j+i_17]*b[i][j+i_18])+s_18;
s_18=d[i][j+2];

for(i_19=i_18+1;i_19<20;i_19++)
{ // 19
d[i][j+1]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15]*b[i][j+i_16]*b[i][j+i_17]*b[i][j+i_18]*b[i][j+i_19])+s_19;
s_19=d[i][j+1];

for(i_20=i_19+1;i_20<20;i_20++)
{ // 20
d[i][j+0]=(b[i][j+i_1]*b[i][j+i_2]*b[i][j+i_3]*b[i][j+i_4]*b[i][j+i_5]*b[i][j+i_6]*b[i][j+i_7]*b[i][j+i_8]*b[i][j+i_9]*b[i][j+i_10]*b[i][j+i_11]*b[i][j+i_12]*b[i][j+i_13]*b[i][j+i_14]*b[i][j+i_15]*b[i][j+i_16]*b[i][j+i_17]*b[i][j+i_18]*b[i][j+i_19]*b[i][j+i_20])+s_20;
s_20=d[i][j+0];

}}}}}}}}}}}}}}}}}}}}
// **********************************************
//*******************************************

}
} //***********************END PARALLEL COMPUTATION *******************************************************
// ***********************************************************************************
// *************************************************


/*

for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
{
printf("%f  ",d[i][j]);
}
printf("\n");
}

printf("\n");
printf("\n");
printf("\n -----------------------------------------------------");
printf("\n");
printf("\n");
 // *****************8
//---------------------------------------
printf("CALCULATE LAMBDA");
printf("\n");
printf("\n"); 

*/

int cnt;
float x1,x2,z,fx1,fdx1;
for(j=0;j<t;j++)
 {
 for(k=0;k<n;k=k+20)
 {

cnt=0,x1=0.5,x2=0,z=0;

    do
    {
            cnt++;
            fx1=fdx1=0;
            for(i=19;i>=1;i--)

            {
                fx1+=d[j][19-i+k] * (pow(x1,i)) ;
            }
            fx1+=d[j][0+k+19];
            for(i=19;i>=1;i--)
            {
                fdx1+=d[j][19-i+k]* (i*pow(x1,(i-1)));
            }

            x2=(x1-(fx1/fdx1));
            z=x1;
            x1=x2;

            //printf("\n %d         %.3f  %.3f  %.3f ",cnt,x1,fx1,fdx1);
// printf("\n");

    }while(fabs(z - x1)>=0.0001);
  //  printf("\n\t THE ROOT OF EQUATION IS %f",x1);  
  e[j][k]=x1;

}
}
// 

/*

for(i=0;i<t;i++)
{
for(j=0;j<n;j=j+20)
printf("%f  ", e[i][j]);

printf("\n");
}
*/

/*
//---------------------------------------

printf("\n ------------------------------------");
printf("\n -------------------------------------");
printf("\n-------------------------------------");

printf("\n");









printf("CALCULATION OF H(I)  THAN SORTING IN DECENDING ORDER AND ARRANGE MU VALUE WITH RESPECT TO H(I)");
printf("\n");
printf("\n");
//---------------------------------------------------
//----------------------------------------------------- 

*/
p=-1;

for(i=0;i<m-1;i++)
for(k=i+1;k<m;k++)
{ 
p++;
for(j=0;j<n;j++)
{
c[p][j]= (float)1-( fabs(a[i+q][j]-a[k+q][j]));

// printf("%f  ",c[p][j]);
}
//printf("\n");
}

//printf("SORTING ARRAY IN DECREASING ORDER"); 



// Array sorting code 
for(k=0;k<t;k++)
for(x=0;x<n;x=x+20)
for(i=0;i<19;i++)
for(j=i+1;j<20;j++)
if(c[k][x+j]>c[k][x+i])
{
temp=c[k][x+i];
c[k][x+i]=c[k][x+j];
c[k][x+j]=temp;

temp1=b[k][x+i];
b[k][x+i]=b[k][x+j];
b[k][x+j]=temp1;
}

// printf("print sorting value");
// printf("\n");
// printf("\n");
 
 /*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ", c[i][j]);
printf("\n");
}
printf("\n-----------------");
printf("\n----------------");
printf("\n--------------------");
printf(" PRINT MU VALUE AFTER ARRANGEMENT ACCORDING AS H(I)");
printf("\n");
printf("\n");
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ",b[i][j]);
printf("\n");
}


//-------------------------------------------
//---------------------------------------------


printf("\n-----------------------------");
printf("\n------------------------");
printf("\n-------------------------");

printf("CALCULATE A[I]");
printf("\n");
printf("\n"); 
*/
for(i=0;i<t;i++)
for(j=0;j<n;j=j+20)
{
d[i][0+j]=b[i][0+j];
d[i][1+j]=b[i][1+j]+d[i][0+j] + e[i][0+j]*b[i][1+j]*d[i][0+j];
d[i][2+j]=b[i][2+j]+d[i][1+j] + e[i][0+j]*b[i][2+j]*d[i][1+j];
d[i][3+j]=b[i][3+j]+d[i][2+j] + e[i][0+j]*b[i][3+j]*d[i][2+j]; // tak tha 
d[i][4+j]=b[i][4+j]+d[i][3+j] + e[i][0+j]*b[i][4+j]*d[i][3+j];
d[i][5+j]=b[i][5+j]+d[i][4+j] + e[i][0+j]*b[i][5+j]*d[i][4+j];
d[i][6+j]=b[i][6+j]+d[i][5+j] + e[i][0+j]*b[i][6+j]*d[i][5+j];
d[i][7+j]=b[i][7+j]+d[i][6+j] + e[i][0+j]*b[i][7+j]*d[i][6+j];
d[i][8+j]=b[i][8+j]+d[i][7+j] + e[i][0+j]*b[i][8+j]*d[i][7+j];
d[i][9+j]=b[i][9+j]+d[i][8+j] + e[i][0+j]*b[i][9+j]*d[i][8+j];
d[i][10+j]=b[i][10+j]+d[i][9+j] + e[i][0+j]*b[i][10+j]*d[i][9+j];
d[i][11+j]=b[i][11+j]+d[i][10+j] + e[i][0+j]*b[i][11+j]*d[i][10+j];
d[i][12+j]=b[i][12+j]+d[i][11+j] + e[i][0+j]*b[i][12+j]*d[i][11+j];
d[i][13+j]=b[i][13+j]+d[i][12+j] + e[i][0+j]*b[i][13+j]*d[i][12+j];
d[i][14+j]=b[i][14+j]+d[i][13+j] + e[i][0+j]*b[i][14+j]*d[i][13+j];
d[i][15+j]=b[i][15+j]+d[i][14+j] + e[i][0+j]*b[i][15+j]*d[i][14+j];
d[i][16+j]=b[i][16+j]+d[i][15+j] + e[i][0+j]*b[i][16+j]*d[i][15+j];
d[i][17+j]=b[i][17+j]+d[i][16+j] + e[i][0+j]*b[i][17+j]*d[i][16+j];
d[i][18+j]=b[i][18+j]+d[i][17+j] + e[i][0+j]*b[i][18+j]*d[i][17+j];
d[i][19+j]=b[i][19+j]+d[i][18+j] + e[i][0+j]*b[i][19+j]*d[i][18+j];
}
//
/* 
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ",d[i][j]);
printf("\n");
}


printf("\n");
printf("\n");
printf("CALCULATE MINIMUM BETWEEN D[i][j] AND C[i][j]");

printf("\n");
printf("\n");
printf("\n");
*/
for(i=0;i<t;i++)
for(k=0;k<n;k++)
{
if(c[i][k]<d[i][k])
{
b[i][k]=c[i][k];
// printf("%f  ",b[p][j]);
}
else
{
b[i][k]=d[i][k];
// printf("%f  ",b[p][j]);
}
}
// printf("\n");





/*
for(i=0;i<t;i++)
{
for(j=0;j<n;j++)
printf("%f  ",b[i][j]);
printf("\n");
}

printf("\n-------------------");
printf("\n");
printf("\n");

printf("CALCULATE MAXIMUM");
printf("\n");
printf("\n");

*/



float g[t],max=0;
for(i=0;i<t;i++)
{
for(j=0;j<n;j=j+20)
{
max=b[i][j];
for(k=0;k<20;k++)
{
if(max < b[i][k+j])
{
max=b[i][j+k];
}
}
g[i]=max; // ***********
g[i]=1-g[i]; // for getting disimiliarity matrix
//  printf("%f  ",g[i]);
 // printf("\n");
}
 // printf("\n");
}




float r[p_1][p_1];

for(i=0;i<p_1;i++)
for(k=0;k<p_1;k++)
r[i][k]=0;

int u=-1;
for(i=0;i<p_1-1;i++)
for(k=i+1;k<p_1;k++)
{
u++;
r[k][i]=r[i][k]=g[u];
}


for(i=0;i<p_1;i++)
{
for(k=0;k<p_1;k++)
printf("%f  ",r[i][k]);
printf("\n");
}
 
// deallocate the previously allocated space.[

free(b);
free(c);
free(d);
free(e);

// **************************]
//printf("\n");

} // end of for loop
// printf("\n");


} //************************************

else if (argc < 4 ||argc > 4)
{
printf("Enter Three arguments. 1_path_of_input_file  2_number_of_Protein_sequences 3_assign_number_of_Thread");
printf("\n");
}




return(0);
}


