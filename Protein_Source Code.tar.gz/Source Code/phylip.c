#include<stdio.h>
#include<string.h>
#include<math.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>



int  main(int argc, char *argv[])

{
if (argc==5)
{ //*************************************

int v_b, mal;  // ************no of species ,  maximum length of DNA and optimal K

v_b=atoi(argv[1]);

mal=atoi(argv[2]);


int v_a=v_b*10;
int s=1; 
int e=v_b*(s-1);  

int i_1,j_1;
float a[v_a][v_b];
FILE *input1;
input1= fopen(argv[3],"r"); // path of input file for similarity matrix.????????????????????????
for(i_1=0;i_1<v_a;i_1++)
for(j_1=0;j_1<v_b;j_1++)
fscanf(input1,"%f",&a[i_1][j_1]);
fclose(input1);
//#################################################################################
i_1=-1;

char *dna;
dna=(char*) malloc(mal*sizeof(char));

int r_1=0;
printf("    %d",v_b); // number of species in first coulmn......??????????????????????????????????????????????????
printf("\n");

FILE *input;
input= fopen(argv[4],"r"); // raw file of sequence with name ????????????????????????????????
while(fgets(dna,mal,input)!=NULL)
{
r_1++;  //  ##########
if((r_1%2)!=0)  // ***for reading odd line from input file******
{ 
int l=strlen(dna);
 // printf("%d    ",l);
int i; 

for(i=1;i<11;i++)
printf("%c",dna[i]);
printf("     ");


i_1++;
for(j_1=0;j_1<v_b-1;j_1++)  
printf("%f  ",a[e+i_1][j_1]);
printf("%f",a[e+i_1][v_b-1]);
printf("\n");


} // ***************** end if loop(help to directly read from fasta file)
} //end while loop
fclose(input);

} //************************************

else if (argc < 5 || argc > 5)
{
printf("Enter Four  arguments: 1_number_of_Protein_sequences  2_maximum_length_among_protein_sequences 3_input_path_file 4_sequence_file");
printf("\n");
}

return(0);


}


